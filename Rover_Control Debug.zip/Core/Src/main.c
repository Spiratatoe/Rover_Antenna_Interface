/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

/* Private define ------------------------------------------------------------*/
#define LIS3DH_ADDR  0x18   // 7-bit address for LIS3DH (use (LIS3DH_ADDR << 1) in HAL functions)
#define LIS2MDL_ADDR 0x1E   // 7-bit address for LIS2MDL

// Rotation time calculation:
#define TIME_PER_DEGREE 0.0123f // MAST: 12.3 ms per degree (adjust as needed)
// For the FS90R servo, a more realistic value for controlled motion might be around 5 ms per degree.
#define TIME_PER_DEGREE2 0.005f // BOX: 5 ms per degree (start here and tune experimentally)

// Define the tolerance for reaching the setpoint (not used directly in code)
#define ERROR_THRESHOLD 0.1f

// Error thresholds for servo adjustments
#define es1 0.1f
#define et1 0.1f
#define es2 0.1f
#define et2 0.1f

// Define the gear ratio
#define gear_ratio  (74.0f / 17.0f)

// Define forward and backward pulse values
#define pwm1_CW 1550
#define pwm1_STOP 1500
#define pwm1_CWW 1406
#define pwm2_CW 1560
#define pwm2_STOP 1500
#define pwm2_CWW 1430

// Define PID activation threshold (in degrees)
#define THRESHOLD 0.5f

// Define maximum allowable integral term to prevent windup
#define MAX_INTEGRAL 100.0f

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;
DMA_HandleTypeDef hdma_tim1_ch1;
DMA_HandleTypeDef hdma_tim3_ch2;
DMA_HandleTypeDef hdma_tim3_ch1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* Function Prototypes */
void Servo_Init(void);

/* PID controller structures */
// MAST MOTOR (Servo1)
typedef struct {
    float Kp_s1;         // Proportional gain (start with 0.5; reduce if overshoot)
    float Ki_s1;         // Integral gain (start with a small value like 0.01)
    float Kd_s1;         // Derivative gain (start with 0.05)
    float setpoint1;     // Target angle (after gear ratio)
    float prev_error_s1; // Previous error
    float integral_s1;   // Integral sum
    float output_s1;     // PID output
} PID_Controller_Speed1;

typedef struct {
    float Kp_t1;         // Proportional gain (start with 0.4)
    float Ki_t1;         // Integral gain (start with 0.005)
    float Kd_t1;         // Derivative gain (start with 0.02)
    float setpoint1;     // Target angle (after gear ratio)
    float prev_error_t1; // Previous error
    float integral_t1;   // Integral sum
    float output_t1;     // PID output
} PID_Controller_Time1;

// BOX MOTOR (Servo2)
typedef struct {
    float Kp_s2;         // Proportional gain (start with 0.45; reduce if servo overreacts)
    float Ki_s2;         // Integral gain (start with 0.007)
    float Kd_s2;         // Derivative gain (start with 0.03)
    float setpoint2;     // Desired angle
    float prev_error_s2; // Previous error
    float integral_s2;   // Integral sum
    float output_s2;     // PID output
} PID_Controller_Speed2;

typedef struct {
    float Kp_t2;         // Proportional gain (start with 0.35)
    float Ki_t2;         // Integral gain (start with 0.004)
    float Kd_t2;         // Derivative gain (start with 0.015)
    float setpoint2;     // Desired angle
    float prev_error_t2; // Previous error
    float integral_t2;   // Integral sum
    float output_t2;     // PID output
} PID_Controller_Time2;

/* PID Initialization functions */
void PID_Init_s1(PID_Controller_Speed1 *pid_s1, float Kp_s1, float Ki_s1, float Kd_s1, float setpoint1)
{
    pid_s1->Kp_s1 = Kp_s1;
    pid_s1->Ki_s1 = Ki_s1;
    pid_s1->Kd_s1 = Kd_s1;
    pid_s1->setpoint1 = setpoint1;
    pid_s1->prev_error_s1 = 0.0f;
    pid_s1->integral_s1 = 0.0f;
    pid_s1->output_s1 = 0.0f;
}

void PID_Init_s2(PID_Controller_Speed2 *pid_s2, float Kp_s2, float Ki_s2, float Kd_s2, float setpoint2)
{
    pid_s2->Kp_s2 = Kp_s2;
    pid_s2->Ki_s2 = Ki_s2;
    pid_s2->Kd_s2 = Kd_s2;
    pid_s2->setpoint2 = setpoint2;
    pid_s2->prev_error_s2 = 0.0f;
    pid_s2->integral_s2 = 0.0f;
    pid_s2->output_s2 = 0.0f;
}

void PID_Init_t1(PID_Controller_Time1 *pid_t1, float Kp_t1, float Ki_t1, float Kd_t1, float setpoint1)
{
    pid_t1->Kp_t1 = Kp_t1;
    pid_t1->Ki_t1 = Ki_t1;
    pid_t1->Kd_t1 = Kd_t1;
    pid_t1->setpoint1 = setpoint1;
    pid_t1->prev_error_t1 = 0.0f;
    pid_t1->integral_t1 = 0.0f;
    pid_t1->output_t1 = 0.0f;
}

void PID_Init_t2(PID_Controller_Time2 *pid_t2, float Kp_t2, float Ki_t2, float Kd_t2, float setpoint2)
{
    pid_t2->Kp_t2 = Kp_t2;
    pid_t2->Ki_t2 = Ki_t2;
    pid_t2->Kd_t2 = Kd_t2;
    pid_t2->setpoint2 = setpoint2;
    pid_t2->prev_error_t2 = 0.0f;
    pid_t2->integral_t2 = 0.0f;
    pid_t2->output_t2 = 0.0f;
}

/* PID Control Calculation functions */
// MAST MOTOR (Servo1)
float PID_Compute_Speed1(PID_Controller_Speed1 *pid_s1, float current_value, float *error_outs1)
{
    float error_s1 = pid_s1->setpoint1 - current_value;
    pid_s1->integral_s1 += error_s1;
    // Anti-windup clamping
    if(pid_s1->integral_s1 > MAX_INTEGRAL) pid_s1->integral_s1 = MAX_INTEGRAL;
    if(pid_s1->integral_s1 < -MAX_INTEGRAL) pid_s1->integral_s1 = -MAX_INTEGRAL;

    float derivative_s1 = error_s1 - pid_s1->prev_error_s1;
    pid_s1->output_s1 = pid_s1->Kp_s1 * error_s1 + pid_s1->Ki_s1 * pid_s1->integral_s1 + pid_s1->Kd_s1 * derivative_s1;
    pid_s1->prev_error_s1 = error_s1;
    *error_outs1 = error_s1;
    return pid_s1->output_s1;
}

float PID_Compute_Time1(PID_Controller_Time1 *pid_t1, float current_value, float dt, float *error_outt1)
{
    float error_t1 = pid_t1->setpoint1 - current_value;
    pid_t1->integral_t1 += error_t1;
    if(pid_t1->integral_t1 > MAX_INTEGRAL) pid_t1->integral_t1 = MAX_INTEGRAL;
    if(pid_t1->integral_t1 < -MAX_INTEGRAL) pid_t1->integral_t1 = -MAX_INTEGRAL;

    float derivative_t1 = (error_t1 - pid_t1->prev_error_t1) / dt;
    pid_t1->output_t1 = pid_t1->Kp_t1 * error_t1 + pid_t1->Ki_t1 * pid_t1->integral_t1 + pid_t1->Kd_t1 * derivative_t1;
    pid_t1->prev_error_t1 = error_t1;
    *error_outt1 = error_t1;
    return pid_t1->output_t1;
}

// BOX MOTOR (Servo2)
float PID_Compute_Speed2(PID_Controller_Speed2 *pid_s2, float current_value, float *error_outs2)
{
    float error_s2 = pid_s2->setpoint2 - current_value;
    pid_s2->integral_s2 += error_s2;
    if(pid_s2->integral_s2 > MAX_INTEGRAL) pid_s2->integral_s2 = MAX_INTEGRAL;
    if(pid_s2->integral_s2 < -MAX_INTEGRAL) pid_s2->integral_s2 = -MAX_INTEGRAL;

    float derivative_s2 = error_s2 - pid_s2->prev_error_s2;
    pid_s2->output_s2 = pid_s2->Kp_s2 * error_s2 + pid_s2->Ki_s2 * pid_s2->integral_s2 + pid_s2->Kd_s2 * derivative_s2;
    pid_s2->prev_error_s2 = error_s2;
    *error_outs2 = error_s2;
    return pid_s2->output_s2;
}

float PID_Compute_Time2(PID_Controller_Time2 *pid_t2, float current_value, float dt, float *error_outt2)
{
    float error_t2 = pid_t2->setpoint2 - current_value;
    pid_t2->integral_t2 += error_t2;
    if(pid_t2->integral_t2 > MAX_INTEGRAL) pid_t2->integral_t2 = MAX_INTEGRAL;
    if(pid_t2->integral_t2 < -MAX_INTEGRAL) pid_t2->integral_t2 = -MAX_INTEGRAL;

    float derivative_t2 = (error_t2 - pid_t2->prev_error_t2) / dt;
    pid_t2->output_t2 = pid_t2->Kp_t2 * error_t2 + pid_t2->Ki_t2 * pid_t2->integral_t2 + pid_t2->Kd_t2 * derivative_t2;
    pid_t2->prev_error_t2 = error_t2;
    *error_outt2 = error_t2;
    return pid_t2->output_t2;
}

/* Servo PWM Control Functions */
// MAST MOTOR (Servo1)
void Set_Servo_PWM1s(uint32_t *servo_pwm1, float pid_output_s1, int ServoPWM1, float error_s1)
{
    if (fabs(error_s1) < THRESHOLD) {
        *servo_pwm1 = pwm1_STOP;
    } else {
        if (fabs(error_s1) > 5 && ServoPWM1 > 1510)
            *servo_pwm1 = ServoPWM1 + pid_output_s1;
        else if (fabs(error_s1) > 5 && ServoPWM1 < 1460)
            *servo_pwm1 = ServoPWM1 - pid_output_s1;
        else if (fabs(error_s1) < 5 && ServoPWM1 > 1510)
            *servo_pwm1 = ServoPWM1 - pid_output_s1;
        else if (fabs(error_s1) < 5 && ServoPWM1 < 1460)
            *servo_pwm1 = ServoPWM1 + pid_output_s1;
    }
}

void Set_Servo_PWM1t(uint32_t *servo_pwm1, float *rotation_time1, float pid_output_t1, int ServoPWM1, float setpoint1, float current_value, float dt, float error_t1)
{
    int pwm_value_s1 = ServoPWM1;
    uint32_t rotation_time = 0;
    if (fabs(error_t1) < THRESHOLD) {
        *rotation_time1 = 0;
        *servo_pwm1 = pwm1_STOP;
    } else {
        rotation_time = (setpoint1 - current_value) / (TIME_PER_DEGREE * 1000) + pid_output_t1;
        *rotation_time1 = rotation_time;
        *servo_pwm1 = pwm_value_s1;
    }
}

// BOX MOTOR (Servo2)
void Set_Servo_PWM2s(uint32_t *servo_pwm2, float pid_output_s2, int ServoPWM2, float error_s2)
{
    if (fabs(error_s2) < THRESHOLD) {
        *servo_pwm2 = 1506;
    } else {
        if (fabs(error_s2) > es2 && ServoPWM2 > 1537)
            *servo_pwm2 = ServoPWM2 + pid_output_s2;
        else if (fabs(error_s2) > es2 && ServoPWM2 < 1476)
            *servo_pwm2 = ServoPWM2 - pid_output_s2;
        else if (fabs(error_s2) < es2 && ServoPWM2 > 1537)
            *servo_pwm2 = ServoPWM2 - pid_output_s2;
        else if (fabs(error_s2) < es2 && ServoPWM2 < 1476)
            *servo_pwm2 = ServoPWM2 + pid_output_s2;
    }
}

void Set_Servo_PWM2t(uint32_t *servo_pwm2, float *rotation_time2, float pid_output_t2, int ServoPWM2, float setpoint2, float current_value, float dt, float error_t2)
{
    int pwm_value_s2 = ServoPWM2;
    uint32_t rotation_time = 0;
    if (fabs(error_t2) < THRESHOLD) {
        *rotation_time2 = 0;
        *servo_pwm2 = pwm2_STOP;
    } else {
        rotation_time = (setpoint2 - current_value) / (TIME_PER_DEGREE * 2000) + pid_output_t2;
        *rotation_time2 = rotation_time;
        *servo_pwm2 = pwm_value_s2;
    }
}

/* Sensor Variables */
float x_accel = 0.0f, y_accel = 0.0f, z_accel = 0.0f, lis3dh_temp = 0.0f;
float x_mag = 0.0f, y_mag = 0.0f, z_mag = 0.0f, lis2mdl_temp = 0.0f;

/* PID Controller Instances */
PID_Controller_Speed1 pid_s1;
PID_Controller_Time1 pid_t1;
PID_Controller_Speed2 pid_s2;
PID_Controller_Time2 pid_t2;

/* Private function prototypes */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);

void lis3dh_init(void) {
    uint8_t buf[2];
    buf[0] = 0x20;      // CTRL_REG_1
    buf[1] = 0x97;      // Normal mode, 1.344 kHz data rate
    HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 100);
    buf[0] = 0x23;      // CTRL_REG_4
    buf[1] = 0x80;      // Block data update
    HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 100);
    buf[0] = 0x1F;      // TEMP_CFG_REG
    buf[1] = 0xC0;
    HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 100);
}

void lis3dh_calc_value(uint16_t raw_value, float *final_value, bool isAccel) {
    float scaling = isAccel ? (64 / 0.004f) : 64;
    *final_value = ((int16_t)raw_value) / scaling;
}

void lis3dh_read_data(uint8_t reg, float *final_value, bool IsAccel) {
    uint8_t data[2];
    HAL_I2C_Mem_Read(&hi2c1, (LIS3DH_ADDR << 1), reg | 0x80, I2C_MEMADD_SIZE_8BIT, data, 2, 100);
    uint16_t raw = (data[1] << 8) | data[0];
    lis3dh_calc_value(raw, final_value, IsAccel);
}

void lis2mdl_init(void) {
    uint8_t buf[2];
    buf[0] = 0x60;      // CFG_REG_A
    buf[1] = 0x80;      // Temperature compensation enabled, continuous mode
    HAL_I2C_Master_Transmit(&hi2c1, (LIS2MDL_ADDR << 1), buf, 2, 100);
    buf[0] = 0x62;      // CFG_REG_C
    buf[1] = 0x01;      // DRDY on INT/DRDY pin enabled
    HAL_I2C_Master_Transmit(&hi2c1, (LIS2MDL_ADDR << 1), buf, 2, 100);
}

void lis2mdl_calc_value(uint16_t raw, float *final_value, bool isMag) {
    *final_value = isMag ? ((int16_t)raw) * 0.0015f : ((int16_t)raw) * 0.125f;
}

void lis2mdl_read_data(uint8_t reg, float *final_value, bool isMag) {
    uint8_t data[2];
    HAL_I2C_Mem_Read(&hi2c1, (LIS2MDL_ADDR << 1), reg | 0x80, I2C_MEMADD_SIZE_8BIT, data, 2, 100);
    uint16_t raw = (data[1] << 8) | data[0];
    lis2mdl_calc_value(raw, final_value, isMag);
}

// Angle calculation functions
float calculate_angle_difference(float x1, float z1, float x2, float z2) {
    float delta_x = x2 - x1;
    float delta_z = z2 - z1;
    return atan2(delta_z, delta_x) * (180.0f / M_PI);
}

float calculate_angle_difference2(float x1, float y1, float z1, float x2, float y2, float z2) {
    float delta_x = x2 - x1, delta_y = y2 - y1, delta_z = z2 - z1;
    float r = sqrt(delta_x * delta_x + delta_z * delta_z);
    return atan2(delta_y, r) * (180.0f / M_PI);
}

float calculate_magnetometer_angle(float x, float z) {
    return atan2(z, x) * (180.0f / M_PI);
}

float calculate_accelerometer_angle(float x, float y, float z) {
    float r = sqrt(x * x + z * z);
    return atan2(y, r) * (180.0f / M_PI);
}

bool is_at_setpoint(float current_value, float setpoint1, float threshold) {
    return fabs(current_value - setpoint1) <= THRESHOLD;
}

bool is_at_setpoint2(float current_value2, float setpoint2, float threshold) {
    return fabs(current_value2 - setpoint2) <= THRESHOLD;
}

int main(void)
{
    char msg[1000];
    HAL_Init();
    Servo_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_DMA_Init();
    MX_I2C1_Init();
    MX_TIM1_Init();
    MX_TIM3_Init();
    MX_USART2_UART_Init();
    MX_USART3_UART_Init();

    HAL_TIM_Base_Start(&htim1);
    HAL_TIM_Base_Start(&htim3);
    __HAL_TIM_SET_COUNTER(&htim3, 0);
    __HAL_TIM_SET_COUNTER(&htim1, 0);

    // Setup PWM channels
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1); // Servo1
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2); // Servo2
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1); // Fan PWM (if used)

    // Define positions for base station and rover
    float base_station_x = 0.0f, base_station_y = 0.0f, base_station_z = 0.0f;
    float rover_initial_x = 5, rover_initial_y = 0, rover_initial_z = 0;
    float rover_second_x = 0, rover_second_y = 5, rover_second_z = 0;
    float rover_initial_r = sqrt(rover_initial_x * rover_initial_x + rover_initial_z * rover_initial_z);
    float rover_second_r = sqrt(rover_second_x * rover_second_x + rover_second_z * rover_second_z);
    float rover_current_x = rover_second_x, rover_current_y = rover_second_y, rover_current_z = rover_second_z;

    // PID Initialization with new parameters (tune these gains experimentally)
    PID_Init_s1(&pid_s1, 0.5f, 0.01f, 0.05f, 0.0f);
    PID_Init_t1(&pid_t1, 0.4f, 0.005f, 0.02f, 0.0f);
    PID_Init_s2(&pid_s2, 0.45f, 0.007f, 0.03f, 0.0f);
    PID_Init_t2(&pid_t2, 0.35f, 0.004f, 0.015f, 0.0f);

    uint32_t prev_time = HAL_GetTick();
    uint32_t ServoPWM1 = pwm1_STOP, ServoPWM2 = pwm2_STOP;
    static bool first_iteration_s1 = true;
    static bool first_iteration_s2 = true;

    while (1)
    {
        uint32_t current_time = HAL_GetTick();
        // Compute time difference (dt) in seconds between iterations
        float dt = (current_time - prev_time) / 1000.0f;
        prev_time = current_time;

        // Read sensor data
        lis3dh_read_data(0x28, &x_accel, true);
        lis3dh_read_data(0x2A, &y_accel, true);
        lis3dh_read_data(0x2C, &z_accel, true);
        lis2mdl_read_data(0x68, &x_mag, true);
        lis2mdl_read_data(0x68, &y_mag, true);
        lis2mdl_read_data(0x68, &z_mag, true);

        // Update positions (hardcoded demonstration values)
        base_station_x = 0; base_station_y = 0; base_station_z = 0;
        rover_initial_x = 5; rover_initial_y = 0; rover_initial_z = 0;
        rover_second_x = 0; rover_second_y = 5; rover_second_z = 0;
        rover_initial_r = sqrt(rover_initial_x * rover_initial_x + rover_initial_z * rover_initial_z);
        rover_second_r = sqrt(rover_second_x * rover_second_x + rover_second_z * rover_second_z);
        rover_current_x = rover_second_x; rover_current_y = rover_second_y; rover_current_z = rover_second_z;

        // --- MAST (Servo1) Calculations ---
        float angle1 = calculate_angle_difference(base_station_x, base_station_z, rover_initial_x, rover_initial_z);
        float angle2 = calculate_angle_difference(base_station_x, base_station_z, rover_current_x, rover_current_z);
        float setpoint_angle = angle2 - angle1;  // Desired angle difference
        float current_angle = calculate_magnetometer_angle(x_mag, z_mag);
        // Update PID setpoints (apply gear ratio for MAST)
        pid_s1.setpoint1 = setpoint_angle * gear_ratio;
        pid_t1.setpoint1 = setpoint_angle * gear_ratio;

        // Compute PID outputs for Servo1 using dt
        float error_values1, error_valuet1, RotationTime1;
        float pid_output_s1 = PID_Compute_Speed1(&pid_s1, current_angle, &error_values1);
        float pid_output_t1 = PID_Compute_Time1(&pid_t1, current_angle, dt, &error_valuet1);

        if (first_iteration_s1) {
            // On first iteration, provide a "kick" to overcome static friction
            ServoPWM1 = (setpoint_angle >= 0) ? pwm1_CW : pwm1_CWW;
            first_iteration_s1 = false;
        } else {
            Set_Servo_PWM1s(&ServoPWM1, pid_output_s1, ServoPWM1, error_values1);
            Set_Servo_PWM1t(&ServoPWM1, &RotationTime1, pid_output_t1, ServoPWM1, setpoint_angle, current_angle, dt, error_valuet1);
        }
        TIM3->CCR1 = ServoPWM1;

        // --- BOX (Servo2) Calculations ---
        float angle3 = calculate_angle_difference2(base_station_x, base_station_y, base_station_z, rover_initial_x, rover_initial_y, rover_initial_z);
        float angle4 = calculate_angle_difference2(base_station_x, base_station_y, base_station_z, rover_current_x, rover_current_y, rover_current_z);
        float setpoint_angle2 = angle4 - angle3;
        float current_angle2 = calculate_accelerometer_angle(x_accel, y_accel, z_accel);
        pid_s2.setpoint2 = setpoint_angle2;
        pid_t2.setpoint2 = setpoint_angle2;

        float error_values2, error_valuet2, RotationTime2;
        float pid_output_s2 = PID_Compute_Speed2(&pid_s2, current_angle2, &error_values2);
        float pid_output_t2 = PID_Compute_Time2(&pid_t2, current_angle2, dt, &error_valuet2);

        if (first_iteration_s2) {
            // Provide an initial kick for Servo2 as well
            ServoPWM2 = (setpoint_angle2 >= 0) ? pwm2_CW : pwm2_CWW;
            first_iteration_s2 = false;
        } else {
            Set_Servo_PWM2s(&ServoPWM2, pid_output_s2, ServoPWM2, error_values2);
            Set_Servo_PWM2t(&ServoPWM2, &RotationTime2, pid_output_t2, ServoPWM2, setpoint_angle2, current_angle2, dt, error_valuet2);
        }
        TIM3->CCR2 = ServoPWM2;

        // Debug output over UART
        snprintf(msg, sizeof(msg), "-----\r\nPWM1: %li, Error1: %.2f, Setpoint MAST: %.2f\r\n", ServoPWM1, error_values1, setpoint_angle);
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
        snprintf(msg, sizeof(msg), "PWM2: %li, Error2: %.2f, Setpoint BOX: %.2f\r\n", ServoPWM2, error_values2, setpoint_angle2);
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

        HAL_Delay(1000); // Delay for smooth operation
    }
}

/* System Clock Configuration */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 8;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* I2C1 Initialization Function */
static void MX_I2C1_Init(void)
{
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x10B17DB5;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
}

/* TIM1 Initialization Function */
static void MX_TIM1_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 63;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.BreakAFMode = TIM_BREAK_AFMODE_INPUT;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.Break2AFMode = TIM_BREAK_AFMODE_INPUT;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_TIM_MspPostInit(&htim1);
}

/* TIM3 Initialization Function */
static void MX_TIM3_Init(void)
{
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 64 - 1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 20000 - 1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_TIM_MspPostInit(&htim3);
}

/* USART2 Initialization Function */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USART3 Initialization Function */
static void MX_USART3_UART_Init(void)
{
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* DMA Initialization Function */
static void MX_DMA_Init(void)
{
  __HAL_RCC_DMA1_CLK_ENABLE();
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  HAL_NVIC_SetPriority(DMA1_Channel2_3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_3_IRQn);
}

/* GPIO Initialization Function */
static void MX_GPIO_Init(void)
{
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
}

/* Servo Initialization */
void Servo_Init(void)
{
    // Initialize PWM channels for servos
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);  // Servo1
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);  // Servo2
}

/* Error Handler */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif /* USE_FULL_ASSERT */

/*
 * magnetometer_calibration.c
 *
 *  Created on: Mar 29, 2025
 *      Author: marcs
 */
#include "magnetometer_calibration.h"
#include <string.h>

// Calibration data arrays:
#define CALIBRATION_POINTS 1750
float mag_x_data[CALIBRATION_POINTS];
float mag_y_data[CALIBRATION_POINTS];
float mag_z_data[CALIBRATION_POINTS];

// Calibration parameters:
float hard_iron_offset_x = 0;
float hard_iron_offset_y = 0;
float hard_iron_offset_z = 0;

float soft_iron_scale_x = 1;
float soft_iron_scale_y = 1;
float soft_iron_scale_z = 1;

void calibrateMagnetometer(I2C_HandleTypeDef *hi2c, UART_HandleTypeDef *huart) {
    // 1. Data Collection
    for (int i = 0; i < CALIBRATION_POINTS; i++) {
        lis2mdl_read_data(hi2c, 0x68, &mag_x_data[i], true);
        lis2mdl_read_data(hi2c, 0x6A, &mag_y_data[i], true);
        lis2mdl_read_data(hi2c, 0x6C, &mag_z_data[i], true);
        HAL_Delay(5);
    }

    // 2. Calibration Algorithm (Simplified Hard Iron)
    float x_min = mag_x_data[0], x_max = mag_x_data[0];
    float y_min = mag_y_data[0], y_max = mag_y_data[0];
    float z_min = mag_z_data[0], z_max = mag_z_data[0];

    for (int i = 1; i < CALIBRATION_POINTS; i++) {
        if (mag_x_data[i] < x_min) x_min = mag_x_data[i];
        if (mag_x_data[i] > x_max) x_max = mag_x_data[i];
        if (mag_y_data[i] < y_min) y_min = mag_y_data[i];
        if (mag_y_data[i] > y_max) y_max = mag_y_data[i];
        if (mag_z_data[i] < z_min) z_min = mag_z_data[i];
        if (mag_z_data[i] > z_max) z_max = mag_z_data[i];
    }

    hard_iron_offset_x = (x_max + x_min) / 2.0;
    hard_iron_offset_y = (y_max + y_min) / 2.0;
    hard_iron_offset_z = (z_max + z_min) / 2.0;



    // Print Calibration results via UART
    char msg[128];
    snprintf(msg, sizeof(msg), "Calibration Results\r\n");
    HAL_UART_Transmit(huart, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    snprintf(msg, sizeof(msg), "Hard Iron Offset X: %f\r\n", hard_iron_offset_x);
    HAL_UART_Transmit(huart, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    snprintf(msg, sizeof(msg), "Hard Iron Offset Y: %f\r\n", hard_iron_offset_y);
    HAL_UART_Transmit(huart, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    snprintf(msg, sizeof(msg), "Hard Iron Offset Z: %f\r\n", hard_iron_offset_z);
    HAL_UART_Transmit(huart, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    snprintf(msg, sizeof(msg), "Soft Iron Scale X: %f\r\n", soft_iron_scale_x);
    HAL_UART_Transmit(huart, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    snprintf(msg, sizeof(msg), "Soft Iron Scale Y: %f\r\n", soft_iron_scale_y);
    HAL_UART_Transmit(huart, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    snprintf(msg, sizeof(msg), "Soft Iron Scale Z: %f\r\n", soft_iron_scale_z);
    HAL_UART_Transmit(huart, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
}

void lis2mdl_calc_value(uint16_t raw, float *final_value, bool isMag) {
    if (isMag) {
        *final_value = ((int16_t)raw) * 0.0015f;
    } else {
        *final_value = ((int16_t)raw) * 0.125f;
    }
}

void lis2mdl_read_data(I2C_HandleTypeDef *hi2c, uint8_t reg, float *final_value, bool isMag) {
    uint8_t data[2];
    HAL_I2C_Mem_Read(hi2c, (LIS2MDL_ADDR << 1), reg | 0x80, I2C_MEMADD_SIZE_8BIT, data, 2, 100);
    uint16_t raw = (data[1] << 8) | data[0];
    lis2mdl_calc_value(raw, final_value, isMag);
}


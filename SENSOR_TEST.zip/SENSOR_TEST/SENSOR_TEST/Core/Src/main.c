/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <string.h>
#include "magnetometer_calibration.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define LIS3DH_ADDR  0x18   // 7-bit address for LIS3DH (use (LIS3DH_ADDR << 1) in HAL functions)
#define LIS2MDL_ADDR 0x1E   // 7-bit address for LIS2MDL
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
float calibration_start_sec = 0;
float calibration_end_sec = 0;
float calibration_duration_sec = 0;
// Variables for LIS3DH sensor
float x_accel = 0.0f, y_accel = 0.0f, z_accel = 0.0f;
float lis3dh_temp = 0.0f;

// Variables for LIS2MDL sensor
float x_mag = 0.0f, y_mag = 0.0f, z_mag = 0.0f;
float lis2mdl_temp = 0.0f;

// Timer variables
volatile uint32_t overflow_count = 0;
uint32_t prev_counter = 0;

char msg[128]; //message buffer

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */

//time print
void time_print(uint32_t total_microSec, int32_t current_count){
	// --- Elapsed Time Calculation ---
		  current_count = __HAL_TIM_GET_COUNTER(&htim1);
		  //detect overflow
		  if (current_count < prev_counter) {
		      overflow_count++;
		  }
		  prev_counter = current_count;

		  // Calculate total time
		  total_microSec = (overflow_count * 0xFFFF) + current_count;
		  float elapsed_seconds = (float)total_microSec / 1e5f;

		  /* --- UART Output --- */
		  snprintf(msg, sizeof(msg), "\033[1;1H\033[2J");  // Clear terminal
		  HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);


		  // Add elapsed time to output
		  snprintf(msg, sizeof(msg), "System Uptime: %.3f seconds\r\n", elapsed_seconds);
		  HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
}

/* --- LIS3DH Functions (Existing Code) --- */

/**
  * @brief  Initialize the LIS3DH sensor.
  */
void lis3dh_init(void) {
    uint8_t buf[2];

    // Turn on normal mode and 1.344 kHz data rate
    buf[0] = 0x20;      // CTRL_REG_1 register
    buf[1] = 0x97;      // 0x97: enable normal mode, 1.344 kHz data rate
    HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 100);

    // Turn on block data update (for temperature sensing)
    buf[0] = 0x23;      // CTRL_REG_4 register
    buf[1] = 0x80;      // enable block data update
    HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 100);

    // Turn on auxiliary ADC (for temperature)
    buf[0] = 0x1F;      // TEMP_CFG_REG register
    buf[1] = 0xC0;
    HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 100);
}

/**
  * @brief  Convert the raw 16-bit sensor value to a float.
  * @param  raw_value: Raw data read from the sensor.
  * @param  final_value: Pointer to the float where the calculated value will be stored.
  * @param  isAccel: true if the value is an acceleration value, false if it is a temperature.
  */
void lis3dh_calc_value(uint16_t raw_value, float *final_value, bool isAccel) {
    float scaling;
    float sensitivity = 0.004f; // g per unit for acceleration

    if (isAccel) {
        scaling = 64 / sensitivity;
    } else {
        scaling = 64;
    }
    // raw_value is signed
    *final_value = ((int16_t)raw_value) / scaling;
}

/**
  * @brief  Read two consecutive bytes from the specified register of LIS3DH and convert to a float.
  * @param  reg: Register address (LSB of the pair).
  * @param  final_value: Pointer to the float where the result will be stored.
  * @param  IsAccel: true if reading acceleration, false for temperature.
  */
void lis3dh_read_data(uint8_t reg, float *final_value, bool IsAccel) {
    uint8_t data[2];
    // Enable auto-increment by setting the MSB of the register address
    HAL_I2C_Mem_Read(&hi2c1, (LIS3DH_ADDR << 1), reg | 0x80, I2C_MEMADD_SIZE_8BIT, data, 2, 100);
    uint16_t raw = (data[1] << 8) | data[0];
    lis3dh_calc_value(raw, final_value, IsAccel);
}

/* --- End of LIS3DH Functions --- */

/* --- LIS2MDL Functions (New Code) --- */

/**
  * @brief  Initialize the LIS2MDL magnetometer.
  *         Configures the sensor for continuous measurement with temperature compensation.
  *         Here, CFG_REG_A (0x60) is set to enable temperature compensation and continuous mode.
  *         CFG_REG_C (0x62) is set to enable the data-ready (DRDY) signal.
  */
void lis2mdl_init(void) {
    uint8_t buf[2];

    // Configure CFG_REG_A: COMP_TEMP_EN = 1, continuous mode (MD = 00), default ODR (10 Hz)
    buf[0] = 0x60;      // CFG_REG_A register address
    buf[1] = 0x80;      // 0x80: temperature compensation enabled, continuous mode
    HAL_I2C_Master_Transmit(&hi2c1, (LIS2MDL_ADDR << 1), buf, 2, 100);

    // Configure CFG_REG_C: Enable DRDY on INT/DRDY pin (bit0 = 1)
    buf[0] = 0x62;      // CFG_REG_C register address
    buf[1] = 0x01;      // DRDY_on_PIN enabled
    HAL_I2C_Master_Transmit(&hi2c1, (LIS2MDL_ADDR << 1), buf, 2, 100);
}
/* --- End of LIS2MDL Functions --- */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART3_UART_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);

  /* Start TIM1 and reset counter */
  HAL_TIM_Base_Start(&htim1);
  __HAL_TIM_SET_COUNTER(&htim1, 0);

  // Get calibration start time
  uint32_t cal_start_us = (overflow_count * 0xFFFF) + __HAL_TIM_GET_COUNTER(&htim1);
  calibration_start_sec = (float)cal_start_us / 1e6f;

  uint32_t current_counter = 0;
  uint32_t total_us = 0;


  // Inform user and initialize both sensors
  snprintf(msg, sizeof(msg), "Initializing LIS3DH and LIS2MDL sensors...\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

  lis3dh_init();
  lis2mdl_init();

  //Calibrate the magnetometer:
  TIM3->CCR1 = 1535;
  time_print(total_us, current_counter);
  snprintf(msg, sizeof(msg), "Calibrating Magnetometer\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

  calibrateMagnetometer(&hi2c1, &huart3);

  TIM3->CCR1 = 1420;
  time_print(total_us, current_counter);
  snprintf(msg, sizeof(msg), "Finished alibrating Magnetometer\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
  HAL_Delay(1000);
  // Get calibration end time and duration
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  int counter = 0;

  while (1){
	  if(counter<251){
		  counter++;
		  if(counter == 250){
			  TIM3->CCR1 = 1500;
		  }
	  }

	  time_print(total_us, current_counter);

      // --- Read LIS3DH (Accelerometer & Temperature) ---
      lis3dh_read_data(0x28, &x_accel, true);
      lis3dh_read_data(0x2A, &y_accel, true);
      lis3dh_read_data(0x2C, &z_accel, true);
      lis3dh_read_data(0x0C, &lis3dh_temp, false);

      // --- Read LIS2MDL (Magnetometer & Temperature) ---
      lis2mdl_read_data(&hi2c1, 0x68, &x_mag, true);
      lis2mdl_read_data(&hi2c1, 0x6A, &y_mag, true);
      lis2mdl_read_data(&hi2c1, 0x6C, &z_mag, true);
      lis2mdl_read_data(&hi2c1, 0x6E, &lis2mdl_temp, false);
      //Apply calibration corrections:
      x_mag = (x_mag - hard_iron_offset_x) / soft_iron_scale_x;
      y_mag = (y_mag - hard_iron_offset_y) / soft_iron_scale_y;
      z_mag = (z_mag - hard_iron_offset_z) / soft_iron_scale_z;


      // Transmit data over UART
      // Print LIS3DH data
      snprintf(msg, sizeof(msg), "--- LIS3DH Sensor ---\r\n");
      HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
      snprintf(msg, sizeof(msg), "Acceleration: X: %.3fg, Y: %.3fg, Z: %.3fg\r\n", x_accel, y_accel, z_accel);
      HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
      snprintf(msg, sizeof(msg), "LIS3DH Temperature: %.3f%cC\r\n", lis3dh_temp, 0xB0);
      HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

      // Print LIS2MDL data
      snprintf(msg, sizeof(msg), "--- LIS2MDL Sensor ---\r\n");
      HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
      snprintf(msg, sizeof(msg), "Magnetic Field: X: %.3f G, Y: %.3f G, Z: %.3f G\r\n", x_mag, y_mag, z_mag);
      HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
      snprintf(msg, sizeof(msg), "LIS2MDL Temperature: %.3f%cC\r\n", lis2mdl_temp, 0xB0);
      HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

      HAL_Delay(125);

      // Optionally clear the terminal (if supported)
      snprintf(msg, sizeof(msg), "\033[1;1H\033[2J");
      HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 8;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x10B17DB5;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 63;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 63;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 20000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

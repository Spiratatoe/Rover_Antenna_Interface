/*
 * magnetometer_calibration.h
 *
 *  Created on: Mar 29, 2025
 *      Author: marcs
 */

#ifndef MAGNETOMETER_CALIBRATION_H_
#define MAGNETOMETER_CALIBRATION_H_

#include "main.h" // Include main.h for HAL and I2C definitions
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#define LIS2MDL_ADDR 0x1E   // Add this line!

// Function prototypes:
void calibrateMagnetometer(I2C_HandleTypeDef *hi2c, UART_HandleTypeDef *huart);
void lis2mdl_read_data(I2C_HandleTypeDef *hi2c, uint8_t reg, float *final_value, bool isMag);
void lis2mdl_calc_value(uint16_t raw, float *final_value, bool isMag);

extern float hard_iron_offset_x;
extern float hard_iron_offset_y;
extern float hard_iron_offset_z;

extern float soft_iron_scale_x;
extern float soft_iron_scale_y;
extern float soft_iron_scale_z;

#endif /* INC_MAGNETOMETER_CALIBRATION_H_ */
